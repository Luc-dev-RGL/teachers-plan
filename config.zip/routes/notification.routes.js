import express from 'express';
import pool from '../config/db.js';

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const { utilisateur_id, non_lues_seulement } = req.query;

    let query = 'SELECT * FROM notifications';
    const conditions = [];
    const params = [];
    let idx = 1;

    if (utilisateur_id) {
      conditions.push(`utilisateur_id = $${idx}`);
      params.push(utilisateur_id); idx++;
    }
    if (non_lues_seulement === 'true') {
      conditions.push(`lu = false`);
    }
    if (conditions.length > 0) query += ' WHERE ' + conditions.join(' AND ');
    query += ' ORDER BY cree_le DESC LIMIT 50';

    const result = await pool.query(query, params);
    res.json({ succes: true, donnees: result.rows });
  } catch (error) {
    console.error('Erreur notifications:', error);
    res.status(500).json({ succes: false, message: 'Erreur serveur' });
  }
});

router.post('/', async (req, res) => {
  try {
    const { utilisateur_id, titre, message, type } = req.body;

    if (!utilisateur_id || !titre || !message) {
      return res.status(400).json({ succes: false, message: 'utilisateur_id, titre et message sont requis' });
    }

    const result = await pool.query(
      `INSERT INTO notifications (utilisateur_id, titre, message, type, lu)
       VALUES ($1, $2, $3, $4, false) RETURNING *`,
      [utilisateur_id, titre, message, type || 'info']
    );

    res.status(201).json({ succes: true, donnees: result.rows[0] });
  } catch (error) {
    console.error('Erreur création notification:', error);
    res.status(500).json({ succes: false, message: 'Erreur serveur' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      'UPDATE notifications SET lu = true WHERE id = $1 RETURNING *', [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ succes: false, message: 'Notification non trouvée' });
    }
    res.json({ succes: true, donnees: result.rows[0] });
  } catch (error) {
    console.error('Erreur notification:', error);
    res.status(500).json({ succes: false, message: 'Erreur serveur' });
  }
});

export { router };