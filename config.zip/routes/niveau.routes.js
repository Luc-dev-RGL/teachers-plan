import express from 'express';
import pool from '../config/db.js';

const router = express.Router();

// GET /api/niveaux
router.get('/', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT n.*, (SELECT COUNT(*) FROM classes c WHERE c.niveau_id = n.id) as nb_classes
       FROM niveaux n ORDER BY n.ordre ASC, n.nom ASC`
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Erreur niveaux:', error);
    res.status(500).json({ message: 'Erreur serveur' });
  }
});

// POST /api/niveaux
router.post('/', async (req, res) => {
  try {
    const { code, nom, ordre } = req.body;
    const result = await pool.query(
      'INSERT INTO niveaux (code, nom, ordre) VALUES ($1, $2, $3) RETURNING *',
      [code, nom, ordre || 0]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Erreur création niveau:', error);
    res.status(500).json({ message: 'Erreur serveur' });
  }
});

// PUT /api/niveaux/:id
router.put('/:id', async (req, res) => {
  try {
    const { code, nom, ordre } = req.body;
    const result = await pool.query(
      'UPDATE niveaux SET code = $1, nom = $2, ordre = $3, modifie_le = CURRENT_TIMESTAMP WHERE id = $4 RETURNING *',
      [code, nom, ordre || 0, req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Niveau non trouvé' });
    }
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Erreur mise à jour niveau:', error);
    res.status(500).json({ message: 'Erreur serveur' });
  }
});

// DELETE /api/niveaux/:id
router.delete('/:id', async (req, res) => {
  try {
    const result = await pool.query(
      'DELETE FROM niveaux WHERE id = $1 RETURNING *',
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Niveau non trouvé' });
    }
    res.json({ message: 'Niveau supprimé' });
  } catch (error) {
    console.error('Erreur suppression niveau:', error);
    res.status(500).json({ message: 'Erreur serveur' });
  }
});

export { router };