import express from 'express';
import pool from '../config/db.js';

const router = express.Router();

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

router.get('/', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM salles ORDER BY nom ASC');
    res.json({ succes: true, donnees: result.rows });
  } catch (error) {
    res.status(500).json({ succes: false, message: 'Erreur serveur' });
  }
});

router.post('/', async (req, res) => {
  try {
    const { code, nom, capacite, type, batiment } = req.body;
    const result = await pool.query(
      'INSERT INTO salles (code, nom, capacite, type, batiment) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [code, nom, capacite || 30, type || 'standard', batiment || null]
    );
    res.status(201).json({ succes: true, donnees: result.rows[0] });
  } catch (error) {
    res.status(500).json({ succes: false, message: error.detail || 'Erreur serveur' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    if (!UUID.test(req.params.id)) return res.status(400).json({ succes: false, message: 'ID invalide' });
    const { code, nom, capacite, type, batiment } = req.body;
    const result = await pool.query(
      'UPDATE salles SET code = $1, nom = $2, capacite = $3, type = $4, batiment = $5, modifie_le = CURRENT_TIMESTAMP WHERE id = $6 RETURNING *',
      [code, nom, capacite, type, batiment, req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ succes: false, message: 'Salle non trouvée' });
    res.json({ succes: true, donnees: result.rows[0] });
  } catch (error) {
    res.status(500).json({ succes: false, message: 'Erreur serveur' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    if (!UUID.test(req.params.id)) return res.status(400).json({ succes: false, message: 'ID invalide' });
    const result = await pool.query('DELETE FROM salles WHERE id = $1 RETURNING *', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ succes: false, message: 'Salle non trouvée' });
    res.json({ succes: true, message: 'Salle supprimée' });
  } catch (error) {
    res.status(500).json({ succes: false, message: 'Erreur serveur' });
  }
});

export { router };