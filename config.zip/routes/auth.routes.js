import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import pool from '../config/db.js';
import { verifierToken } from '../middlewares/auth.middleware.js';

const router = express.Router();

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, mot_de_passe } = req.body;

    if (!email || !mot_de_passe) {
      return res.status(400).json({ message: 'Email et mot de passe requis' });
    }

    const result = await pool.query('SELECT * FROM utilisateurs WHERE email = $1', [email]);
    const utilisateur = result.rows[0];

    if (!utilisateur || !utilisateur.actif) {
      return res.status(401).json({ message: 'Email ou mot de passe incorrect' });
    }

    const motDePasseValide = await bcrypt.compare(mot_de_passe, utilisateur.mot_de_passe);
    if (!motDePasseValide) {
      return res.status(401).json({ message: 'Email ou mot de passe incorrect' });
    }

    // Récupérer l'enseignant associé si existe
    const ensRes = await pool.query('SELECT id FROM enseignants WHERE utilisateur_id = $1', [utilisateur.id]);
    const enseignant_id = ensRes.rows[0]?.id || null;

    const token = jwt.sign(
      { id: utilisateur.id, email: utilisateur.email, role: utilisateur.role, enseignant_id },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '24h' }
    );

    res.json({
      succes: true,
      token,
      utilisateur: {
        id: utilisateur.id,
        email: utilisateur.email,
        nom: utilisateur.nom,
        prenom: utilisateur.prenom,
        role: utilisateur.role,
        enseignant_id,
      },
    });
  } catch (error) {
    console.error('Erreur login:', error);
    res.status(500).json({ message: 'Erreur serveur' });
  }
});

// GET /api/auth/profil  (alias /me)
router.get('/profil', verifierToken, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, email, nom, prenom, role, actif, avatar, cree_le FROM utilisateurs WHERE id = $1',
      [req.utilisateur.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Utilisateur non trouvé' });
    }
    const ensRes = await pool.query('SELECT * FROM enseignants WHERE utilisateur_id = $1', [req.utilisateur.id]);
    res.json({
      succes: true,
      utilisateur: { ...result.rows[0], enseignant: ensRes.rows[0] || null },
    });
  } catch (error) {
    res.status(500).json({ message: 'Erreur serveur' });
  }
});

// Alias GET /api/auth/me
router.get('/me', verifierToken, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, email, nom, prenom, role, actif, avatar, cree_le FROM utilisateurs WHERE id = $1',
      [req.utilisateur.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Utilisateur non trouvé' });
    }
    res.json({ succes: true, utilisateur: result.rows[0] });
  } catch (error) {
    res.status(500).json({ message: 'Erreur serveur' });
  }
});

// PUT /api/auth/profil
router.put('/profil', verifierToken, async (req, res) => {
  try {
    const { nom, prenom, email, avatar } = req.body;
    const result = await pool.query(
      `UPDATE utilisateurs SET nom = $1, prenom = $2, email = $3, avatar = $4, modifie_le = CURRENT_TIMESTAMP
       WHERE id = $5 RETURNING id, email, nom, prenom, role, actif, avatar`,
      [nom, prenom, email, avatar, req.utilisateur.id]
    );
    res.json({ succes: true, utilisateur: result.rows[0], message: 'Profil mis à jour' });
  } catch (error) {
    res.status(500).json({ message: 'Erreur serveur' });
  }
});

export { router };
