import express from 'express';
import pool from '../config/db.js';

const router = express.Router();

// GET /api/departements
router.get('/', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM departements ORDER BY nom ASC');
    res.json({ succes: true, donnees: result.rows });
  } catch (error) {
    console.error('Erreur départements:', error);
    res.status(500).json({ succes: false, message: 'Erreur serveur' });
  }
});

// POST /api/departements
router.post('/', async (req, res) => {
  try {
    const { code, nom, description, chef_id } = req.body;
    const result = await pool.query(
      'INSERT INTO departements (code, nom, description, chef_id) VALUES ($1, $2, $3, $4) RETURNING *',
      [code, nom, description, chef_id]
    );
    res.json({ succes: true, donnees: result.rows[0] });
  } catch (error) {
    console.error('Erreur création département:', error);
    res.status(500).json({ succes: false, message: 'Erreur serveur' });
  }
});

// PUT /api/departements/:id
router.put('/:id', async (req, res) => {
  try {
    const { code, nom, description, chef_id } = req.body;
    const result = await pool.query(
      'UPDATE departements SET code = $1, nom = $2, description = $3, chef_id = $4 WHERE id = $5 RETURNING *',
      [code, nom, description, chef_id, req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ succes: false, message: 'Département non trouvé' });
    }
    res.json({ succes: true, donnees: result.rows[0] });
  } catch (error) {
    console.error('Erreur mise à jour département:', error);
    res.status(500).json({ succes: false, message: 'Erreur serveur' });
  }
});

// DELETE /api/departements/:id
router.delete('/:id', async (req, res) => {
  try {
    const result = await pool.query(
      'DELETE FROM departements WHERE id = $1 RETURNING *',
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ succes: false, message: 'Département non trouvé' });
    }
    res.json({ succes: true, message: 'Département supprimé' });
  } catch (error) {
    console.error('Erreur suppression département:', error);
    res.status(500).json({ succes: false, message: 'Erreur serveur' });
  }
});

export { router };