import pool from '../config/db.js';

export const lister = async (req, res) => {
  try {
    const notifications = [];
    const today = new Date().toISOString().split('T')[0];
    const ilYa3Jours = new Date(Date.now() - 3 * 86400000).toISOString().split('T')[0];
    const debutMois = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0];
    const finMois = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).toISOString().split('T')[0];

    // 1. Séances aujourd'hui
    const aujourdhui = await pool.query(
      `SELECT COUNT(*) as total FROM seances_cours WHERE date = $1 AND statut = 'planifiee'`, [today]
    );
    const nbAujourdhui = parseInt(aujourdhui.rows[0].total);
    if (nbAujourdhui > 0) {
      notifications.push({
        id: 'seances-today',
        type: 'info',
        titre: `${nbAujourdhui} séance${nbAujourdhui > 1 ? 's' : ''} aujourd'hui`,
        description: `Séances de cours prévues pour le ${new Date().toLocaleDateString('fr-FR')}`,
        page: 'seances',
        date: today,
        lu: false,
      });
    }

    // 2. Séances non validées (> 3 jours)
    const nonValidees = await pool.query(
      `SELECT COUNT(*) as total FROM seances_cours WHERE date < $1 AND statut = 'planifiee'`, [ilYa3Jours]
    );
    const nbNonValidees = parseInt(nonValidees.rows[0].total);
    if (nbNonValidees > 0) {
      notifications.push({
        id: 'seances-pending',
        type: 'warning',
        titre: `${nbNonValidees} séance${nbNonValidees > 1 ? 's' : ''} à valider`,
        description: 'Des séances passées de plus de 3 jours attendent validation',
        page: 'seances',
        date: today,
        lu: false,
      });
    }

    // 3. Conflits de salles
    const conflits = await pool.query(
      `SELECT salle_id, date, heure_debut, COUNT(*) as nb FROM seances_cours
       WHERE date >= $1
       GROUP BY salle_id, date, heure_debut
       HAVING COUNT(*) > 1`, [today]
    );
    if (conflits.rows.length > 0) {
      notifications.push({
        id: 'salles-conflit',
        type: 'danger',
        titre: `${conflits.rows.length} conflit${conflits.rows.length > 1 ? 's' : ''} de salles`,
        description: 'Plusieurs séances planifiées dans la même salle au même créneau',
        page: 'seances',
        date: today,
        lu: false,
      });
    }

    // 4. Heures non payées
    const nonPayees = await pool.query(
      `SELECT COUNT(*) as total FROM heures_effectuees WHERE statut = 'validee'`
    );
    const nbNonPayees = parseInt(nonPayees.rows[0].total);
    if (nbNonPayees > 0) {
      notifications.push({
        id: 'heures-unpaid',
        type: 'warning',
        titre: `${nbNonPayees} ligne${nbNonPayees > 1 ? 's' : ''} d'heures non payée${nbNonPayees > 1 ? 's' : ''}`,
        description: "Des heures validées n'ont pas encore été marquées comme payées",
        page: 'heures',
        date: today,
        lu: false,
      });
    }

    // 5. Enseignants sans département
    const sansDept = await pool.query(
      `SELECT COUNT(*) as total FROM enseignants WHERE departement_id IS NULL AND statut = 'actif'`
    );
    const nbSansDept = parseInt(sansDept.rows[0].total);
    if (nbSansDept > 0) {
      notifications.push({
        id: 'enseignants-no-dept',
        type: 'info',
        titre: `${nbSansDept} enseignant${nbSansDept > 1 ? 's' : ''} sans département`,
        description: 'Des enseignants actifs ne sont affectés à aucun département',
        page: 'enseignants',
        date: today,
        lu: false,
      });
    }

    // 6. Séances du mois
    const moisResult = await pool.query(
      `SELECT COUNT(*) as total FROM seances_cours WHERE date >= $1 AND date <= $2 AND statut != 'annulee'`,
      [debutMois, finMois]
    );
    const nbMois = parseInt(moisResult.rows[0].total);
    if (nbMois > 0) {
      notifications.push({
        id: 'seances-mois',
        type: 'success',
        titre: `${nbMois} séances ce mois`,
        description: `Planning du mois de ${new Date().toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' })}`,
        page: 'emploi-du-temps',
        date: today,
        lu: false,
      });
    }

    res.json({
      succes: true,
      donnees: notifications,
      meta: {
        total: notifications.length,
        nonLues: notifications.filter((n) => !n.lu).length,
        seancesMois: nbMois,
      },
    });
  } catch (error) {
    console.error('Erreur notifications:', error);
    res.json({ succes: true, donnees: [], meta: { total: 0, nonLues: 0 } });
  }
};