import jwt from 'jsonwebtoken';

function verifierToken(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ message: 'Token manquant' });
    }

    // Accepter "Bearer" ET "Porteur"
    const parts = authHeader.split(' ');
    const token = parts.length >= 2 ? parts[1] : null;
    if (!token) {
      return res.status(401).json({ message: 'Token manquant' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.utilisateur = decoded;
    next();
  } catch (error) {
    console.error('Erreur vérification token:', error);
    res.status(401).json({ message: 'Token invalide' });
  }
}

function verifierRole(...roles) {
  return (req, res, next) => {
    if (!req.utilisateur) {
      return res.status(401).json({ message: 'Non authentifié' });
    }
    if (!roles.includes(req.utilisateur.role)) {
      return res.status(403).json({ message: 'Accès refusé' });
    }
    next();
  };
}

const authMiddleware = verifierToken;

export { verifierToken, verifierRole, authMiddleware };