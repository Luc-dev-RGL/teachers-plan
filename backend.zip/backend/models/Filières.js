import pool from '../config/db.js';

export default class Filiere {
  static async creer({ code, nom, description, departement_id }) {
    const resultat = await pool.query(
      `INSERT INTO filieres (code, nom, description, departement_id) VALUES ($1, $2, $3, $4) RETURNING *`,
      [code, nom, description || null, departement_id]
    );
    return resultat.rows[0];
  }

  static async lister({ recherche, departement_id } = {}) {
    let conditions = [];
    const params = [];
    let index = 1;

    if (recherche) {
      conditions.push(`f.code ILIKE $${index} OR f.nom ILIKE $${index}`);
      params.push(`%${recherche}%`);
      index++;
    }
    if (departement_id) { conditions.push(`f.departement_id = $${index++}`); params.push(departement_id); }

    const where = conditions.length > 0 ? 'WHERE ' + conditions.join(' AND ') : '';

    const resultat = await pool.query(`
      SELECT f.*, d.nom as departement_nom, d.code as departement_code,
             (SELECT COUNT(*) FROM classes c WHERE c.filiere_id = f.id) as nb_classes
      FROM filieres f JOIN departements d ON d.id = f.departement_id
      ${where} ORDER BY f.nom ASC
    `, params);
    return resultat.rows;
  }

  static async trouverParId(id) {
    const resultat = await pool.query(`
      SELECT f.*, d.nom as departement_nom,
             (SELECT COUNT(*) FROM classes c WHERE c.filiere_id = f.id) as nb_classes
      FROM filieres f JOIN departements d ON d.id = f.departement_id
      WHERE f.id = $1
    `, [id]);
    return resultat.rows[0];
  }

  static async modifier(id, { code, nom, description, departement_id }) {
    const resultat = await pool.query(
      `UPDATE filieres SET code = $1, nom = $2, description = $3, departement_id = $4, modifie_le = CURRENT_TIMESTAMP
       WHERE id = $5 RETURNING *`,
      [code, nom, description || null, departement_id, id]
    );
    return resultat.rows[0];
  }

  static async supprimer(id) {
    const resultat = await pool.query(`DELETE FROM filieres WHERE id = $1 RETURNING *`, [id]);
    return resultat.rows[0];
  }
}