import { useState, useEffect, useCallback } from 'react';
import api from '../services/api.js';

export default function useFetch(url, options = {}) {
  const [donnees, setDonnees] = useState(null);
  const [chargement, setChargement] = useState(true);
  const [erreur, setErreur] = useState(null);

  const charger = useCallback(async () => {
    setChargement(true);
    try {
      const { data } = await api.get(url, options);
      setDonnees(data);
      setErreur(null);
    } catch (err) {
      setErreur(err.response?.data?.message || 'Erreur de chargement');
    } finally {
      setChargement(false);
    }
  }, [url]);

  useEffect(() => { charger(); }, [charger]);

  return { donnees, chargement, erreur, recharger: charger };
}