const variantes = {
  planifiee: 'bg-amber-50 text-amber-700 border-amber-200',
  effectuee: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  annulee: 'bg-red-50 text-red-700 border-red-200',
  actif: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  inactif: 'bg-slate-50 text-slate-600 border-slate-200',
  suspendu: 'bg-red-50 text-red-700 border-red-200',
  Permanent: 'bg-sky/10 text-navy border-sky/20',
  Vacataire: 'bg-amber-50 text-amber-700 border-amber-200',
  CM: 'bg-violet-50 text-violet-700 border-violet-200',
  TD: 'bg-sky/10 text-navy border-sky/20',
  TP: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  validee: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  payee: 'bg-sky/10 text-navy border-sky/20',
};

export default function Badge({ variant = 'planifiee', children }) {
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${variantes[variant] || variantes.planifiee}`}>
      {children}
    </span>
  );
}