import { X } from 'lucide-react';

export default function Alerte({ type = 'info', message, fermer }) {
  const styles = {
    info: 'bg-sky/10 text-navy border-sky/20',
    succes: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    erreur: 'bg-red-50 text-red-700 border-red-200',
    avertissement: 'bg-amber-50 text-amber-700 border-amber-200',
  };

  return (
    <div className={`flex items-center gap-3 px-4 py-3 rounded-xl border text-sm ${styles[type]}`}>
      <p className="flex-1">{message}</p>
      {fermer && <button onClick={fermer}><X size={16} /></button>}
    </div>
  );
}