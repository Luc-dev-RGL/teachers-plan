export default function Bouton({ enfants, onClick, type = 'button', variant = 'primaire', disabled = false, className = '' }) {
  const styles = {
    primaire: 'bg-navy hover:bg-midnight text-white',
    danger: 'bg-red-500 hover:bg-red-600 text-white',
    secondaire: 'bg-slate-100 hover:bg-slate-200 text-midnight',
    outline: 'border border-slate-200 hover:bg-slate-50 text-midnight',
  };

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`h-10 px-4 rounded-xl text-sm font-medium transition-all duration-200 disabled:opacity-50 flex items-center justify-center gap-2 ${styles[variant]} ${className}`}
    >
      {enfants}
    </button>
  );
}