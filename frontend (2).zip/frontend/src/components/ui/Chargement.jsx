export default function Chargement({ texte = 'Chargement...' }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 gap-3">
      <div className="animate-spin rounded-full h-8 w-8 border-4 border-navy border-t-transparent"></div>
      <p className="text-sm text-slate-400">{texte}</p>
    </div>
  );
}