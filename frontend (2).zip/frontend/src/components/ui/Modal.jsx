import { X } from 'lucide-react';

export default function Modal({ ouvert, fermer, titre, enfants, taille = 'md' }) {
  if (!ouvert) return null;

  const tailles = {
    sm: 'max-w-md',
    md: 'max-w-lg',
    lg: 'max-w-2xl',
    xl: 'max-w-4xl',
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="fixed inset-0 bg-black/40 backdrop-blur-sm" onClick={fermer}></div>
      <div className={`relative bg-white rounded-2xl shadow-xl w-full ${tailles[taille]} mx-4 max-h-[85vh] flex flex-col animate-fade-in`}>
        <div className="flex items-center justify-between p-5 border-b border-slate-200">
          <h3 className="font-display font-bold text-lg text-midnight">{titre}</h3>
          <button onClick={fermer} className="p-1 rounded-lg hover:bg-slate-100 transition-colors">
            <X size={20} className="text-slate-400" />
          </button>
        </div>
        <div className="p-5 overflow-y-auto">{enfants}</div>
      </div>
    </div>
  );
}