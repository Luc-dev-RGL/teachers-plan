export default function Pagination({ page, total, parPage = 10, changer }) {
  const pages = Math.ceil(total / parPage);
  if (pages <= 1) return null;

  return (
    <div className="flex items-center justify-center gap-1 mt-4">
      <button onClick={() => changer(page - 1)} disabled={page <= 1} className="px-3 py-1.5 rounded-lg text-sm border border-slate-200 disabled:opacity-30 hover:bg-slate-50">Préc.</button>
      {Array.from({ length: pages }, (_, i) => i + 1).map((p) => (
        <button key={p} onClick={() => changer(p)} className={`w-8 h-8 rounded-lg text-sm font-medium ${p === page ? 'bg-navy text-white' : 'hover:bg-slate-100'}`}>{p}</button>
      ))}
      <button onClick={() => changer(page + 1)} disabled={page >= pages} className="px-3 py-1.5 rounded-lg text-sm border border-slate-200 disabled:opacity-30 hover:bg-slate-50">Suiv.</button>
    </div>
  );
}