export default function Select({ label, options = [], requi, ...props }) {
  return (
    <div>
      {label && <label className="block text-sm font-medium text-midnight mb-1">{label}{requi && ' *'}</label>}
      <select
        {...props}
        className="w-full h-10 px-3 rounded-lg border border-slate-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-navy/20 transition-all"
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>{opt.label}</option>
        ))}
      </select>
    </div>
  );
}