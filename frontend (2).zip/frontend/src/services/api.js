import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.response.use(
  (reponse) => reponse,
  (erreur) => {
    if (erreur.response?.status === 401) {
      localStorage.removeItem('tp_token');
      localStorage.removeItem('tp_utilisateur');
      window.location.href = '/connexion';
    }
    return Promise.reject(erreur);
  }
);

export default api;