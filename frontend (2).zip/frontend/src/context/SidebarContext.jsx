import { createContext, useContext, useState } from 'react';

export const SidebarContext = createContext(null);

export const SidebarProvider = ({ enfants }) => {
  const [ouvert, setOuvert] = useState(true);
  return (
    <SidebarContext.Provider value={{ ouvert, setOuvert }}>
      {enfants}
    </SidebarContext.Provider>
  );
};

export const utiliserSidebar = () => {
  const context = useContext(SidebarContext);
  if (!context) throw new Error('utiliserSidebar doit être utilisé dans SidebarContext');
  return context;
};