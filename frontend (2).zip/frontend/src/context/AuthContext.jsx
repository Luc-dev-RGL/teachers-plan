import { createContext, useContext } from 'react';

export const AuthContext = createContext(null);

export const utiliserAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('utiliserAuth doit être utilisé dans AuthContext');
  return context;
};