import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';

export default function Classes() {
  const { axios } = useAuth();
  const [classes, setClasses] = useState([]);
  const [filieres, setFilieres] = useState([]);
  const [niveaux, setNiveaux] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ nom: '', code: '', filiere_id: '', niveau_id: '', capacite: '' });

  const fetchData = async () => {
    try {
      const [resClasses, resFilieres, resNiveaux] = await Promise.all([
        axios.get('/api/enseignants/classes'),
        axios.get('/api/enseignants/filieres'),
        axios.get('/api/enseignants/niveaux')
      ]);
      setClasses(resClasses.data);
      setFilieres(resFilieres.data);
      setNiveaux(resNiveaux.data);
    } catch (err) {
      toast.error('Erreur lors du chargement');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const payload = { ...form, capacite: parseInt(form.capacite) || 0 };
      if (editing) {
        await axios.put(`/api/enseignants/classes/${editing.id}`, payload);
        toast.success('Classe modifiée');
      } else {
        await axios.post('/api/enseignants/classes', payload);
        toast.success('Classe créée');
      }
      resetAndClose();
      fetchData();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Erreur');
    }
  };

  const handleEdit = (c) => {
    setEditing(c);
    setForm({ nom: c.nom, code: c.code, filiere_id: c.filiere_id, niveau_id: c.niveau_id, capacite: c.capacite?.toString() || '' });
    setShowModal(true);
  };

  const handleDelete = async (id) => {
    if (!confirm('Supprimer cette classe ?')) return;
    try {
      await axios.delete(`/api/enseignants/classes/${id}`);
      toast.success('Classe supprimée');
      fetchData();
    } catch (err) {
      toast.error('Impossible de supprimer');
    }
  };

  const resetAndClose = () => {
    setShowModal(false);
    setEditing(null);
    setForm({ nom: '', code: '', filiere_id: '', niveau_id: '', capacite: '' });
  };

  const getFiliereNom = (id) => { const f = filieres.find(x => x.id === id); return f ? f.nom : '—'; };
  const getNiveauNom = (id) => { const n = niveaux.find(x => x.id === id); return n ? n.nom : '—'; };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#0F2B46]">Classes</h1>
          <p className="text-gray-500 mt-1">Gestion des classes de l'établissement</p>
        </div>
        <button onClick={() => { resetAndClose(); setShowModal(true); }} className="bg-[#1E6091] hover:bg-[#164a73] text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
          Nouvelle classe
        </button>
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1E6091]" /></div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left px-6 py-3 text-sm font-semibold text-gray-600">Code</th>
                <th className="text-left px-6 py-3 text-sm font-semibold text-gray-600">Nom</th>
                <th className="text-left px-6 py-3 text-sm font-semibold text-gray-600">Filière</th>
                <th className="text-left px-6 py-3 text-sm font-semibold text-gray-600">Niveau</th>
                <th className="text-left px-6 py-3 text-sm font-semibold text-gray-600">Capacité</th>
                <th className="text-right px-6 py-3 text-sm font-semibold text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {classes.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-12 text-gray-400">Aucune classe trouvée</td></tr>
              ) : (
                classes.map((c) => (
                  <tr key={c.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4"><span className="bg-[#48A9C5]/10 text-[#1E6091] text-xs font-mono px-2 py-1 rounded">{c.code}</span></td>
                    <td className="px-6 py-4 font-medium text-[#0F2B46]">{c.nom}</td>
                    <td className="px-6 py-4 text-gray-500 text-sm">{getFiliereNom(c.filiere_id)}</td>
                    <td className="px-6 py-4"><span className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded-full">{getNiveauNom(c.niveau_id)}</span></td>
                    <td className="px-6 py-4 text-sm text-gray-500">{c.capacite || '—'}</td>
                    <td className="px-6 py-4 text-right space-x-2">
                      <button onClick={() => handleEdit(c)} className="text-[#1E6091] hover:text-[#164a73] p-1 rounded hover:bg-[#1E6091]/5 transition-colors" title="Modifier">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                      </button>
                      <button onClick={() => handleDelete(c.id)} className="text-red-500 hover:text-red-700 p-1 rounded hover:bg-red-50 transition-colors" title="Supprimer">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-[#0F2B46]">{editing ? 'Modifier la classe' : 'Nouvelle classe'}</h2>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Code *</label>
                <input type="text" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-[#48A9C5] focus:border-transparent outline-none" placeholder="Ex: L1-INFO-A" required />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nom *</label>
                <input type="text" value={form.nom} onChange={(e) => setForm({ ...form, nom: e.target.value })} className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-[#48A9C5] focus:border-transparent outline-none" placeholder="Ex: Licence 1 Info Groupe A" required />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Filière *</label>
                <select value={form.filiere_id} onChange={(e) => setForm({ ...form, filiere_id: e.target.value })} className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-[#48A9C5] focus:border-transparent outline-none" required>
                  <option value="">-- Sélectionner --</option>
                  {filieres.map(f => <option key={f.id} value={f.id}>{f.nom}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Niveau *</label>
                <select value={form.niveau_id} onChange={(e) => setForm({ ...form, niveau_id: e.target.value })} className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-[#48A9C5] focus:border-transparent outline-none" required>
                  <option value="">-- Sélectionner --</option>
                  {niveaux.map(n => <option key={n.id} value={n.id}>{n.nom}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Capacité</label>
                <input type="number" value={form.capacite} onChange={(e) => setForm({ ...form, capacite: e.target.value })} className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-[#48A9C5] focus:border-transparent outline-none" placeholder="Ex: 40" />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={resetAndClose} className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors">Annuler</button>
                <button type="submit" className="flex-1 bg-[#1E6091] hover:bg-[#164a73] text-white px-4 py-2 rounded-lg transition-colors">{editing ? 'Modifier' : 'Créer'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}