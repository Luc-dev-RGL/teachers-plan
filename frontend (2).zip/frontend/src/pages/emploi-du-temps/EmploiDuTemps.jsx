import { useState, useEffect } from 'react';
import api from '../../services/api.js';
import Badge from '../../components/ui/Badge.jsx';
import Chargement from '../../components/ui/Chargement.jsx';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const jours = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
const creneaux = ['08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00'];

export default function EmploiDuTemps() {
  const [seances, setSeances] = useState([]);
  const [classes, setClasses] = useState([]);
  const [classeId, setClasseId] = useState('');
  const [chargement, setChargement] = useState(true);

  useEffect(() => {
    api.get('/enseignants/classes').then(({ data }) => setClasses(data.donnees)).catch(() => {});
  }, []);

  useEffect(() => {
    setChargement(true);
    api.get('/seances/emploi-du-temps', { params: { classe_id: classeId } })
      .then(({ data }) => setSeances(data.donnees))
      .catch(() => setSeances([]))
      .finally(() => setChargement(false));
  }, [classeId]);

  const getCreneauIndex = (heure) => {
    const h = parseInt(heure.split(':')[0]);
    return h - 8;
  };

  const getJourSemaine = (dateStr) => {
    const date = new Date(dateStr);
    const jour = date.getDay();
    return jour === 0 ? 6 : jour - 1;
  };

  const couleurs = { CM: 'bg-violet-100 border-violet-300 text-violet-800', TD: 'bg-sky/20 border-sky/30 text-navy', TP: 'bg-emerald-50 border-emerald-200 text-emerald-800' };

  if (chargement) return <Chargement />;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-2xl text-midnight">Emploi du temps</h1>
          <p className="text-slate-500 text-sm">{seances.length} séance(s) programmée(s)</p>
        </div>
        <select value={classeId} onChange={(e) => setClasseId(e.target.value)}
          className="h-10 px-4 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-navy/20">
          <option value="">Toutes les classes</option>
          {classes.map((c) => <option key={c.id} value={c.id}>{c.nom}</option>)}
        </select>
      </div>

      <div className="bg-white rounded-xl border border-slate-100 overflow-x-auto">
        <table className="w-full min-w-[800px]">
          <thead>
            <tr className="border-b border-slate-100">
              <th className="w-20 px-2 py-2 text-xs font-semibold text-slate-500">Heure</th>
              {jours.map((j) => <th key={j} className="px-2 py-2 text-xs font-semibold text-slate-500">{j}</th>)}
            </tr>
          </thead>
          <tbody>
            {creneaux.map((creneau, ci) => (
              <tr key={creneau} className="border-b border-slate-50">
                <td className="px-2 py-1 text-xs text-slate-500 text-center">{creneau}</td>
                {jours.map((jour, ji) => {
                  const seance = seances.find((s) => {
                    const idx = getJourSemaine(s.date);
                    const cIdx = getCreneauIndex(s.heure_debut);
                    return idx === ji && cIdx === ci;
                  });
                  return (
                    <td key={ji} className="px-1 py-1 align-top h-12">
                      {seance ? (
                        <div className={`rounded-lg border p-1.5 text-[10px] ${couleurs[seance.type_seance] || couleurs.TD}`}>
                          <p className="font-semibold truncate">{seance.matiere_nom}</p>
                          <p className="truncate">{seance.enseignant_prenom} {seance.enseignant_nom}</p>
                          <p className="truncate opacity-70">{seance.salle_nom}</p>
                          <p className="opacity-50">{seance.heure_debut}-{seance.heure_fin}</p>
                        </div>
                      ) : null}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}