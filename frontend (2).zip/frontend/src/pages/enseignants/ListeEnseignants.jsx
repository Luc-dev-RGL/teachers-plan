import './Enseignants.css';

export default function ListeEnseignants({ enseignants, loading, onEdit, onDelete, departements }) {
  const getDeptNom = (id) => {
    const d = departements.find(x => x.id === id);
    return d ? d.nom : '—';
  };

  const roleBadge = (role) => {
    const map = {
      admin: { label: 'Admin', cls: 'badge-red' },
      rh: { label: 'RH', cls: 'badge-purple' },
      enseignant: { label: 'Enseignant', cls: 'badge-green' },
    };
    const r = map[role] || { label: role, cls: 'badge-gray' };
    return <span className={`badge ${r.cls}`}>{r.label}</span>;
  };

  return (
    <div className="table-container">
      {loading ? (
        <div className="loading-center">
          <div className="spinner"></div>
          <p>Chargement des enseignants...</p>
        </div>
      ) : enseignants.length === 0 ? (
        <div className="empty-state">
          <svg className="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
          <p>Aucun enseignant trouvé</p>
        </div>
      ) : (
        <table className="data-table">
          <thead>
            <tr>
              <th>Matricule</th>
              <th>Nom complet</th>
              <th>Email</th>
              <th>Département</th>
              <th>Spécialité</th>
              <th>Grade</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {enseignants.map((ens) => (
              <tr key={ens.id}>
                <td><span className="badge badge-teal">{ens.matricule}</span></td>
                <td className="font-medium text-[#0F2B46]">{ens.prenom} {ens.nom}</td>
                <td className="text-gray-500 text-sm">{ens.email}</td>
                <td className="text-sm">{getDeptNom(ens.departement_id)}</td>
                <td className="text-sm text-gray-600">{ens.specialite || '—'}</td>
                <td className="text-sm text-gray-600">{ens.grade || '—'}</td>
                <td>
                  <div className="action-buttons">
                    <button onClick={() => onEdit(ens)} className="btn-icon btn-edit" title="Modifier">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                      </svg>
                    </button>
                    <button onClick={() => onDelete(ens.id)} className="btn-icon btn-delete" title="Supprimer">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}