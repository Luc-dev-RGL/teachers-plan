import { useState } from 'react';
import './Enseignants.css';

const emptyForm = {
  matricule: '', nom: '', prenom: '', email: '', telephone: '',
  specialite: '', grade: 'Assistant', departement_id: '', mot_de_passe: ''
};

export default function FormulaireEnseignant({ onClose, onSaved, editing, departements, axios }) {
  const [form, setForm] = useState(editing ? {
    matricule: editing.matricule || '', nom: editing.nom || '', prenom: editing.prenom || '',
    email: editing.email || '', telephone: editing.telephone || '',
    specialite: editing.specialite || '', grade: editing.grade || 'Assistant',
    departement_id: editing.departement_id || '', mot_de_passe: ''
  } : { ...emptyForm });
  const [saving, setSaving] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editing) {
        await axios.put(`/api/enseignants/${editing.id}`, form);
      } else {
        await axios.post('/api/enseignants', form);
      }
      onSaved();
    } catch (err) {
      alert(err.response?.data?.message || 'Erreur lors de l\'enregistrement');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{editing ? 'Modifier l\'enseignant' : 'Nouvel enseignant'}</h2>
          <button className="btn-close" onClick={onClose}>×</button>
        </div>
        <form onSubmit={handleSubmit} className="modal-body">
          <div className="form-row">
            <div className="form-group">
              <label>Matricule *</label>
              <input name="matricule" value={form.matricule} onChange={handleChange} placeholder="Ex: ENS-001" required disabled={!!editing} />
            </div>
            <div className="form-group">
              <label>Grade *</label>
              <select name="grade" value={form.grade} onChange={handleChange} required>
                <option value="Assistant">Assistant</option>
                <option value="Maître Assistant">Maître Assistant</option>
                <option value="Maître de Conférences">Maître de Conférences</option>
                <option value="Professeur">Professeur</option>
              </select>
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Prénom *</label>
              <input name="prenom" value={form.prenom} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Nom *</label>
              <input name="nom" value={form.nom} onChange={handleChange} required />
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Email *</label>
              <input name="email" type="email" value={form.email} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Téléphone</label>
              <input name="telephone" value={form.telephone} onChange={handleChange} placeholder="+225 01 02 03 04" />
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Spécialité</label>
              <input name="specialite" value={form.specialite} onChange={handleChange} />
            </div>
            <div className="form-group">
              <label>Département *</label>
              <select name="departement_id" value={form.departement_id} onChange={handleChange} required>
                <option value="">-- Sélectionner --</option>
                {departements.map(d => <option key={d.id} value={d.id}>{d.nom}</option>)}
              </select>
            </div>
          </div>
          {!editing && (
            <div className="form-group">
              <label>Mot de passe *</label>
              <input name="mot_de_passe" type="password" value={form.mot_de_passe} onChange={handleChange} required minLength={6} placeholder="Minimum 6 caractères" />
            </div>
          )}
          <div className="form-actions">
            <button type="button" className="btn-secondary" onClick={onClose}>Annuler</button>
            <button type="submit" className="btn-primary" disabled={saving}>
              {saving ? 'Enregistrement...' : editing ? 'Modifier' : 'Créer'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}