import { useEffect, useState } from 'react';
import api from '../../services/api.js';
import Badge from '../../components/ui/Badge.jsx';
import Chargement from '../../components/ui/Chargement.jsx';
import { Users, Calendar, Clock, DoorOpen } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function TableauDeBord() {
  const [donnees, setDonnees] = useState(null);
  const [chargement, setChargement] = useState(true);

  useEffect(() => {
    api.get('/tableau-de-bord').then(({ data }) => setDonnees(data)).catch(() => {}).finally(() => setChargement(false));
  }, []);

  if (chargement) return <Chargement />;
  if (!donnees) return <p className="text-center text-slate-500 py-10">Aucune donnée</p>;

  const { statistiques, departements, seances_recentes, annee } = donnees;

  const cartes = [
    { label: 'Enseignants actifs', valeur: statistiques.nb_enseignants, icone: Users, couleur: 'from-navy to-sky' },
    { label: 'Séances ce mois', valeur: statistiques.seances_ce_mois, icone: Calendar, couleur: 'from-emerald-500 to-emerald-400' },
    { label: 'Heures effectuées', valeur: parseFloat(statistiques.total_heures).toFixed(1), icone: Clock, couleur: 'from-amber-500 to-amber-400' },
    { label: 'Salles', valeur: statistiques.nb_salles, icone: DoorOpen, couleur: 'from-violet-500 to-violet-400' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="font-display font-bold text-2xl text-midnight">Tableau de bord</h1>
        <p className="text-slate-500 text-sm">Année : {annee?.libelle}</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {cartes.map((c) => (
          <div key={c.label} className="bg-white rounded-xl p-5 border border-slate-100 hover:shadow-md transition-shadow">
            <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${c.couleur} flex items-center justify-center mb-3`}>
              <c.icone size={20} className="text-white" />
            </div>
            <p className="font-display font-bold text-2xl text-midnight">{c.valeur}</p>
            <p className="text-xs text-slate-500 mt-1">{c.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-xl p-5 border border-slate-100">
          <h3 className="font-display font-semibold text-midnight mb-4">Heures par département</h3>
          {departements?.length > 0 ? (
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={departements}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis dataKey="nom" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip contentStyle={{ borderRadius: '12px', border: '1px solid #E2E8F0' }} formatter={(v) => [`${v} h`, 'Heures']} />
                <Bar dataKey="heures" fill="#1E6091" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : <p className="text-sm text-slate-400 text-center py-10">Aucune donnée</p>}
        </div>

        <div className="bg-white rounded-xl p-5 border border-slate-100">
          <h3 className="font-display font-semibold text-midnight mb-4">Séances récentes</h3>
          <div className="space-y-3 max-h-[320px] overflow-y-auto">
            {seances_recentes?.length > 0 ? seances_recentes.map((s, i) => (
              <div key={i} className="flex items-center gap-3 p-3 rounded-lg hover:bg-slate-50 transition-colors">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-midnight truncate">{s.matiere_nom}</p>
                  <p className="text-xs text-slate-400">{s.enseignant_prenom} {s.enseignant_nom} — {s.classe_nom}</p>
                  <p className="text-xs text-slate-400">{s.date} {s.heure_debut}-{s.heure_fin}</p>
                </div>
                <Badge variant={s.statut}>{s.statut}</Badge>
              </div>
            )) : <p className="text-sm text-slate-400 text-center py-10">Aucune séance</p>}
          </div>
        </div>
      </div>
    </div>
  );
}