import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import api from '../../services/api.js';

export default function ReinitialiserMdp() {
  const [motDePasse, setMotDePasse] = useState('');
  const [confirmation, setConfirmation] = useState('');
  const naviguer = useNavigate();

  const soumettre = async (e) => {
    e.preventDefault();
    if (motDePasse !== confirmation) return toast.error('Les mots de passe ne correspondent pas');
    try {
      await api.post('/auth/reinitialiser', { jeton: window.location.search.split('=')[1], mot_de_passe: motDePasse });
      toast.success('Mot de passe modifié');
      naviguer('/connexion');
    } catch (erreur) {
      toast.error('Erreur');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-snow p-8">
      <div className="w-full max-w-md bg-white rounded-2xl p-8 shadow-sm border border-slate-100">
        <h2 className="font-display font-bold text-2xl text-midnight mb-6">Nouveau mot de passe</h2>
        <form onSubmit={soumettre} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-midnight mb-1">Nouveau mot de passe</label>
            <input type="password" value={motDePasse} onChange={(e) => setMotDePasse(e.target.value)} required
              className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-navy/20" />
          </div>
          <div>
            <label className="block text-sm font-medium text-midnight mb-1">Confirmer</label>
            <input type="password" value={confirmation} onChange={(e) => setConfirmation(e.target.value)} required
              className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-navy/20" />
          </div>
          <button type="submit" className="w-full h-10 bg-navy hover:bg-midnight text-white rounded-xl text-sm font-medium transition-all">Modifier</button>
        </form>
      </div>
    </div>
  );
}