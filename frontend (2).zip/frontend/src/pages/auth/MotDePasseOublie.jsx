import { useState } from 'react';
import toast from 'react-hot-toast';
import api from '../../services/api.js';

export default function MotDePasseOublie() {
  const [email, setEmail] = useState('');
  const [envoye, setEnvoye] = useState(false);

  const soumettre = async (e) => {
    e.preventDefault();
    if (!email) return;
    try {
      await api.post('/auth/mot-de-passe-oublie', { email });
      setEnvoye(true);
      toast.success('Email envoyé');
    } catch (erreur) {
      toast.error('Erreur');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-snow p-8">
      <div className="w-full max-w-md bg-white rounded-2xl p-8 shadow-sm border border-slate-100">
        <h2 className="font-display font-bold text-2xl text-midnight mb-2">Mot de passe oublié</h2>
        {envoye ? (
          <div className="text-center py-8">
            <p className="text-sm text-slate-600">Un email a été envoyé à <strong>{email}</strong></p>
          </div>
        ) : (
          <form onSubmit={soumettre} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-midnight mb-1">Email</label>
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required
                className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-navy/20" />
            </div>
            <button type="submit" className="w-full h-10 bg-navy hover:bg-midnight text-white rounded-xl text-sm font-medium transition-all">Envoyer</button>
          </form>
        )}
      </div>
    </div>
  );
}