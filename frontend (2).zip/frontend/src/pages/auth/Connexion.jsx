import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { utiliserAuth } from '../../context/AuthContext.jsx';
import api from '../../services/api.js';
import toast from 'react-hot-toast';
import { Clock, Eye, EyeOff } from 'lucide-react';

export default function Connexion() {
  const [email, setEmail] = useState('');
  const [motDePasse, setMotDePasse] = useState('');
  const [visible, setVisible] = useState(false);
  const [chargement, setChargement] = useState(false);
  const { connexion } = utiliserAuth();
  const naviguer = useNavigate();

  const soumettre = async (e) => {
    e.preventDefault();
    if (!email || !motDePasse) return toast.error('Remplissez tous les champs');

    setChargement(true);
    try {
      const { data } = await api.post('/auth/connexion', { email, mot_de_passe: motDePasse });
      connexion(data.token, data.utilisateur);
      toast.success(`Bienvenue ${data.utilisateur.prenom} !`);
      naviguer('/');
    } catch (erreur) {
      toast.error(erreur.response?.data?.message || 'Erreur de connexion');
    } finally {
      setChargement(false);
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Gauche - branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-midnight via-navy to-sky relative overflow-hidden">
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-12">
          <div className="w-24 h-24 rounded-3xl bg-white/10 backdrop-blur-sm flex items-center justify-center mb-8">
            <Clock size={48} className="text-white" />
          </div>
          <h1 className="font-display font-extrabold text-4xl mb-4">Teacher's Plan</h1>
          <p className="text-xl text-white/80 mb-12">Planifiez. Suivez. Payez.</p>
          <div className="grid grid-cols-2 gap-6 text-center">
            {[
              { chiffre: '500+', texte: 'Enseignants' },
              { chiffre: '50+', texte: 'Départements' },
              { chiffre: '10k+', texte: 'Séances' },
              { chiffre: '99.9%', texte: 'Disponibilité' },
            ].map((stat) => (
              <div key={stat.texte} className="bg-white/10 rounded-xl p-4 backdrop-blur-sm">
                <p className="font-display font-bold text-2xl">{stat.chiffre}</p>
                <p className="text-sm text-white/70">{stat.texte}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Droite - formulaire */}
      <div className="flex-1 flex items-center justify-center p-8 bg-snow">
        <div className="w-full max-w-md animate-fade-in">
          <div className="lg:hidden flex items-center gap-3 mb-10">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-midnight to-sky flex items-center justify-center">
              <Clock size={20} className="text-white" />
            </div>
            <span className="font-display font-bold text-xl text-midnight">Teacher's Plan</span>
          </div>

          <h2 className="font-display font-bold text-3xl text-midnight mb-2">Connexion</h2>
          <p className="text-slate-500 mb-8">Accédez à votre espace de gestion</p>

          <form onSubmit={soumettre} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-midnight mb-1.5">Adresse email</label>
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="votre@email.com"
                className="w-full h-11 px-4 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-navy/20 focus:border-navy transition-all" />
            </div>
            <div>
              <label className="block text-sm font-medium text-midnight mb-1.5">Mot de passe</label>
              <div className="relative">
                <input type={visible ? 'text' : 'password'} value={motDePasse} onChange={(e) => setMotDePasse(e.target.value)} placeholder="••••••••"
                  className="w-full h-11 px-4 pr-11 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-navy/20 focus:border-navy transition-all" />
                <button type="button" onClick={() => setVisible(!visible)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                  {visible ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>
            <button type="submit" disabled={chargement}
              className="w-full h-11 bg-navy hover:bg-midnight text-white rounded-xl font-medium text-sm transition-all duration-200 disabled:opacity-50 flex items-center justify-center gap-2">
              {chargement ? <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div> : 'Se connecter'}
            </button>
          </form>

          <div className="mt-8 p-4 rounded-xl bg-ice border border-sky/20">
            <p className="text-xs font-medium text-navy mb-2">Comptes de test :</p>
            <div className="space-y-1 text-xs text-slate-500">
              <p><span className="font-medium text-midnight">Admin :</span> admin@teachersplan.com / admin123</p>
              <p><span className="font-medium text-midnight">RH :</span> rh@teachersplan.com / rh123</p>
              <p><span className="font-medium text-midnight">Enseignant :</span> prof@teachersplan.com / prof123</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}